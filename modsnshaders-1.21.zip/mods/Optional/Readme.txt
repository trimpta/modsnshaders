--Optional Mods heavily alter the gameplay--

-betterstats-3.12.2+fabric-1.21: This Minecraft mod replaces the Vanilla statistics screen with an new and improved statistics screen that is easier to use and that has more helpful features. The new statistics screen features an easier to navigate and read UI layout, as well as a few filters and a search field that will help you find the statictics you need a lot easier, especially when there are dozens, if not hundreds of entries to keep track of.

-bobby-5.2.3+mc1.21: Bobby is a Minecraft mod which allows for render distances greater than the server's view-distance setting.

-CraftPresence-2.4.3+1.21: Completely customize the way others see you play Minecraft via Discord's Rich Presence API & the DiscordIPC API by jagrosh!

-InventoryProfilesNext-fabric-1.21-2.0.2: Take control over you inventory. Sort. Move matching Items. Throw all. Locked slots. Gear sets! And much more.

-morechathistory-1.3.1: This mod increases the maximum length of the chat history, from the vanilla 100 messages to 16384.

-MouseTweaks-fabric-mc1.21-2.26: Enhances inventory management by adding various functions to the mouse buttons. 

-PresenceFootsteps-1.10.0+1.21: ..An Overly complicated Sound Mod...

-replaymod-1.21-2.6.17: A Minecraft Mod to record, relive and share your experience.

---------------------------------------------
Other Optional mods left out of the folder which are:

-appleskin-fabric-mc1.21-3.0.2
-BetterF3-11.0.1-Fabric-1.21
-bettermounthud-1.2.4